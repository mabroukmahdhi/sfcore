﻿// ---------------------------------------------------------------
// Copyright (c) Coalition of the Good-Hearted Engineers 
// ---------------------------------------------------------------

namespace $safeprojectname$.Models.Messages
{
    public class Message
    {
        public string Text { get; set; }
    }
}
