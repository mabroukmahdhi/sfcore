﻿// ---------------------------------------------------------------
// Copyright (c) Coalition of the Good-Hearted Engineers 
// ---------------------------------------------------------------
using Xeptions;

namespace $safeprojectname$.Models.WeatherForecasts.Exceptions
{
    public class NullWeatherForecastException : Xeption
    {
        public NullWeatherForecastException()
            : base(message: "WeatherForecast is null.")
        { }
    }
}
