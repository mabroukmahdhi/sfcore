﻿// ---------------------------------------------------------------
// Copyright (c) Coalition of the Good-Hearted Engineers 
// ---------------------------------------------------------------
namespace $safeprojectname$.Borkers.Storages
{
    public partial interface IStorageBroker
    {
    }
}
